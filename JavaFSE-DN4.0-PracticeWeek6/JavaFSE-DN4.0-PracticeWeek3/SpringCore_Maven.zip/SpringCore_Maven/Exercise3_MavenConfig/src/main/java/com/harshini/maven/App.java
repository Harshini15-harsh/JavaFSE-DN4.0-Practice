package com.harshini.maven;

public class App {
    public static void main(String[] args) {
        System.out.println(" Maven Project Configured Successfully -  Harshini ");
    }
}
