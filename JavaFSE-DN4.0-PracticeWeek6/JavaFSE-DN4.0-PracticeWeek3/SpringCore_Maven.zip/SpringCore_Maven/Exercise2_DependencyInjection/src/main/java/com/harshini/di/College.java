package com.harshini.di;

public class College {
    public void collegeInfo() {
        System.out.println("🏫 Harshini Engineering College - Department of Spring 💐");
    }
}
